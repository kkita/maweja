import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import ClientNav from "../../components/ClientNav";
import { useAuth } from "../../lib/auth";
import { useI18n } from "../../lib/i18n";
import { apiRequest, queryClient, authFetch } from "../../lib/queryClient";
import { useToast } from "../../hooks/use-toast";
import {
  ArrowLeft, Calendar, Clock, User, Phone, MapPin, Tag, DollarSign,
  Camera, FileText, MessageCircle, Send, CheckCircle2, Loader2, AlertTriangle
} from "lucide-react";
import type { ServiceRequest } from "@shared/schema";

function parseMinPrice(priceStr: string): number | null {
  const match = priceStr.match(/\$(\d+)/);
  return match ? parseInt(match[1], 10) : null;
}

const inputClass = "w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 rounded-xl text-sm focus:ring-2 focus:ring-red-500 focus:outline-none";
const inputWithIconClass = "w-full pl-9 pr-3 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 rounded-xl text-sm focus:ring-2 focus:ring-red-500 focus:outline-none";
const cardClass = "bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm";
const labelClass = "text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1 block";
const sectionTitleClass = "font-bold text-sm text-gray-900 dark:text-white mb-1 flex items-center gap-2";

export default function ServiceRequestPage() {
  const [currentPath, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const { t } = useI18n();

  const pathParts = currentPath.split("/");
  const requestId = pathParts[pathParts.length - 1];
  const isViewMode = pathParts.includes("request") && requestId && !isNaN(Number(requestId));

  const stored = sessionStorage.getItem("maweja_service_request");
  const catalogData = stored ? JSON.parse(stored) : null;

  const categoryId = catalogData?.categoryId || null;
  const categoryName = catalogData?.categoryName || "";
  const catalogItemId = catalogData?.catalogItemId || null;
  const catalogItemName = catalogData?.catalogItemName || null;
  const catalogItemPrice = catalogData?.catalogItemPrice || null;
  const catalogItemImage = catalogData?.catalogItemImage || null;

  const hasCatalogModel = !!catalogItemName;
  const minPrice = catalogItemPrice ? parseMinPrice(catalogItemPrice) : null;

  const { data: existingRequest } = useQuery<ServiceRequest>({
    queryKey: ["/api/service-requests", requestId],
    queryFn: () => authFetch(`/api/service-requests/${requestId}`).then(r => r.json()),
    enabled: !!isViewMode && !!user,
  });

  const [scheduledType, setScheduledType] = useState("asap");
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [budget, setBudget] = useState("");
  const [additionalInfo, setAdditionalInfo] = useState("");
  const [contactMethod, setContactMethod] = useState("phone");
  const [submitted, setSubmitted] = useState(false);
  const [priceError, setPriceError] = useState("");

  useEffect(() => {
    if (user && !fullName) {
      setFullName(user.name || "");
      setPhone(user.phone || "");
      setAddress(user.address || "");
    }
  }, [user]);

  const serviceTypeOptions: Record<string, string[]> = {
    Hotellerie: ["Reservation chambre", "Suite VIP", "Salle de conference", "Reception", "Autre"],
    Transport: ["Vehicule prive", "Minibus", "Camion", "Moto", "Quad", "Autre"],
    Nettoyage: ["Maison", "Bureau", "Apres evenement", "Vitres", "Tapis", "Autre"],
    Demenagement: ["Local", "Interurbain", "Bureau", "Entrepot", "Autre"],
    Evenementiel: ["Mariage", "Anniversaire", "Conference", "Soiree", "Team building", "Autre"],
    Reparation: ["Plomberie", "Electricite", "Peinture", "Menuiserie", "Electronique", "Autre"],
    Coursier: ["Document", "Colis petit", "Colis moyen", "Colis lourd", "Achats", "Autre"],
    Autre: ["A preciser"],
  };

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/service-requests", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
      setSubmitted(true);
    },
    onError: () => {
      toast({ title: t.common.error, description: t.common.error, variant: "destructive" });
    },
  });

  const validatePrice = (value: string): boolean => {
    if (!minPrice || !value.trim()) return true;
    const numMatch = value.match(/(\d+)/);
    if (!numMatch) return true;
    const enteredPrice = parseInt(numMatch[1], 10);
    if (enteredPrice < minPrice) {
      setPriceError(`${t.services.priceTooLow} (${t.services.minPrice}: $${minPrice})`);
      return false;
    }
    setPriceError("");
    return true;
  };

  const handleBudgetChange = (value: string) => {
    setBudget(value);
    if (priceError) validatePrice(value);
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();

    if (!phone.trim()) {
      toast({ title: t.common.error, description: t.common.phone, variant: "destructive" });
      return;
    }

    if (hasCatalogModel && budget.trim() && !validatePrice(budget)) {
      return;
    }

    if (!hasCatalogModel && (!fullName.trim() || !phone.trim() || !address.trim())) {
      toast({ title: t.common.error, description: t.common.error, variant: "destructive" });
      return;
    }

    createMutation.mutate({
      categoryId: Number(categoryId),
      categoryName,
      scheduledType,
      scheduledDate: scheduledType === "scheduled" ? scheduledDate : null,
      scheduledTime: scheduledType === "scheduled" ? scheduledTime : null,
      fullName: fullName || user?.name || "",
      phone,
      address: address || user?.address || "",
      serviceType: catalogItemName ? `${catalogItemName}${serviceType ? ` - ${serviceType}` : ""}` : serviceType,
      budget: budget || catalogItemPrice || "",
      additionalInfo: hasCatalogModel
        ? `[${t.services.selectedModel}: ${catalogItemName}${catalogItemPrice ? ` (${catalogItemPrice})` : ""}]${catalogItemImage ? `\n[Image: ${catalogItemImage}]` : ""}${additionalInfo ? `\n${additionalInfo}` : ""}`
        : additionalInfo,
      contactMethod,
    });
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24">
        <ClientNav />
        <div className="max-w-lg mx-auto px-4 py-12">
          <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 p-8 text-center shadow-sm">
            <div className="w-20 h-20 bg-green-50 dark:bg-green-950/40 rounded-full flex items-center justify-center mx-auto mb-5">
              <CheckCircle2 size={40} className="text-green-600" />
            </div>
            <h2 className="text-xl font-black text-gray-900 dark:text-white mb-2" data-testid="text-request-sent">{t.services.requestSent}</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">{t.services.requestSentDesc}</p>

            {hasCatalogModel && catalogItemImage && (
              <div className="mb-6 rounded-2xl overflow-hidden border border-gray-100 dark:border-gray-800">
                <img src={catalogItemImage} alt={catalogItemName || ""} className="w-full h-48 object-cover" />
              </div>
            )}

            <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-4 mb-6 text-left">
              <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">{t.services.summary}</p>
              <div className="space-y-1">
                <p className="text-sm text-gray-700 dark:text-gray-300"><strong>{t.services.service}:</strong> {categoryName}</p>
                {catalogItemName && <p className="text-sm text-gray-700 dark:text-gray-300"><strong>{t.services.selectedModel}:</strong> {catalogItemName}</p>}
                {(budget || catalogItemPrice) && <p className="text-sm text-gray-700 dark:text-gray-300"><strong>{t.services.yourPrice}:</strong> {budget || catalogItemPrice}</p>}
                <p className="text-sm text-gray-700 dark:text-gray-300"><strong>{t.services.contact}:</strong> {contactMethod === "whatsapp" ? "WhatsApp" : contactMethod === "phone" ? t.services.telephone : t.common.email}</p>
              </div>
            </div>
            <button
              onClick={() => navigate("/services")}
              data-testid="button-back-services"
              className="w-full bg-red-600 text-white py-3.5 rounded-xl text-sm font-bold hover:bg-red-700 shadow-lg shadow-red-200"
            >
              {t.services.backToServices}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (isViewMode && existingRequest) {
    const statusLabels: Record<string, string> = {
      pending: t.services.statusPending, reviewing: t.services.statusReviewing, accepted: t.services.statusAccepted, rejected: t.services.statusRejected, completed: t.services.statusCompleted,
    };
    const statusColors: Record<string, string> = {
      pending: "bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800",
      reviewing: "bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-800",
      accepted: "bg-green-50 dark:bg-green-950/40 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800",
      rejected: "bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800",
      completed: "bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700",
    };

    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24">
        <ClientNav />
        <div className="max-w-lg mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-6">
            <button onClick={() => navigate("/services")} className="w-10 h-10 bg-white dark:bg-gray-900 rounded-xl flex items-center justify-center border border-gray-200 dark:border-gray-700" data-testid="button-back">
              <ArrowLeft size={18} className="dark:text-gray-300" />
            </button>
            <div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-white">{t.services.request} #{existingRequest.id}</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">{existingRequest.categoryName}</p>
            </div>
          </div>

          <div className={`rounded-2xl border p-4 mb-4 ${statusColors[existingRequest.status] || statusColors.pending}`}>
            <p className="font-bold text-sm">{t.common.status}: {statusLabels[existingRequest.status] || existingRequest.status}</p>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-5 space-y-4">
            <div><p className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase">{t.services.fullName}</p><p className="text-sm text-gray-900 dark:text-white font-medium">{existingRequest.fullName}</p></div>
            <div><p className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase">{t.common.phone}</p><p className="text-sm text-gray-900 dark:text-white font-medium">{existingRequest.phone}</p></div>
            <div><p className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase">{t.common.address}</p><p className="text-sm text-gray-900 dark:text-white font-medium">{existingRequest.address}</p></div>
            {existingRequest.serviceType && <div><p className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase">{t.services.type}</p><p className="text-sm text-gray-900 dark:text-white font-medium">{existingRequest.serviceType}</p></div>}
            {existingRequest.budget && <div><p className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase">{t.admin.budget}</p><p className="text-sm text-gray-900 dark:text-white font-medium">{existingRequest.budget}</p></div>}
            <div>
              <p className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase">{t.admin.schedule}</p>
              <p className="text-sm text-gray-900 dark:text-white font-medium">
                {existingRequest.scheduledType === "asap" ? t.services.asap : `${existingRequest.scheduledDate} ${existingRequest.scheduledTime}`}
              </p>
            </div>
            {existingRequest.additionalInfo && <div><p className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase">{t.services.additionalInfo}</p><p className="text-sm text-gray-700 dark:text-gray-300">{existingRequest.additionalInfo}</p></div>}
            {existingRequest.adminNotes && (
              <div className="bg-blue-50 dark:bg-blue-950/40 rounded-xl p-4 border border-blue-100 dark:border-blue-800">
                <p className="text-[10px] font-bold text-blue-700 dark:text-blue-400 uppercase mb-1">{t.services.teamResponse}</p>
                <p className="text-sm text-blue-800 dark:text-blue-300">{existingRequest.adminNotes}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (hasCatalogModel) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24">
        <ClientNav />
        <div className="max-w-lg mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-4">
            <button onClick={() => navigate("/services")} className="w-10 h-10 bg-white dark:bg-gray-900 rounded-xl flex items-center justify-center border border-gray-200 dark:border-gray-700" data-testid="button-back">
              <ArrowLeft size={18} className="dark:text-gray-300" />
            </button>
            <div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-white" data-testid="text-form-title">{t.services.quickRequest}</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">{categoryName}</p>
            </div>
          </div>

          {catalogItemImage && (
            <div className="rounded-2xl overflow-hidden border border-gray-100 dark:border-gray-800 shadow-sm mb-4">
              <img src={catalogItemImage} alt={catalogItemName || ""} className="w-full h-56 object-cover" data-testid="img-selected-model" />
            </div>
          )}

          <div className="bg-red-50 dark:bg-red-950/40 rounded-2xl border border-red-200 dark:border-red-800 p-4 mb-4 flex items-center gap-3">
            {catalogItemImage && (
              <img src={catalogItemImage} alt={catalogItemName || ""} className="w-14 h-14 rounded-xl object-cover border-2 border-red-300 dark:border-red-700" />
            )}
            <div className="flex-1">
              <p className="text-[10px] font-semibold text-red-500 uppercase">{t.services.selectedModel}</p>
              <p className="font-bold text-sm text-gray-900 dark:text-white" data-testid="text-model-name">{catalogItemName}</p>
              {catalogItemPrice && <p className="text-xs text-red-600 dark:text-red-400 font-semibold">{catalogItemPrice}</p>}
            </div>
          </div>

          <p className="text-xs text-gray-400 dark:text-gray-500 mb-4 px-1">{t.services.quickRequestDesc}</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className={`${cardClass} p-5`}>
              <h3 className={sectionTitleClass}>
                <Calendar size={16} className="text-red-500" />
                {t.services.dateTime}
              </h3>
              <div className="flex gap-2 mb-3">
                <button type="button" onClick={() => setScheduledType("asap")}
                  data-testid="button-asap"
                  className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all ${scheduledType === "asap" ? "bg-red-600 text-white shadow-lg shadow-red-200" : "bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700"}`}>
                  <Clock size={14} className="inline mr-1.5" />{t.services.asap}
                </button>
                <button type="button" onClick={() => setScheduledType("scheduled")}
                  data-testid="button-schedule"
                  className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all ${scheduledType === "scheduled" ? "bg-red-600 text-white shadow-lg shadow-red-200" : "bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700"}`}>
                  <Calendar size={14} className="inline mr-1.5" />{t.services.schedule}
                </button>
              </div>
              {scheduledType === "scheduled" && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={labelClass}>{t.common.date}</label>
                    <input type="date" value={scheduledDate} onChange={e => setScheduledDate(e.target.value)}
                      data-testid="input-date" className={inputClass} />
                  </div>
                  <div>
                    <label className={labelClass}>Heure</label>
                    <input type="time" value={scheduledTime} onChange={e => setScheduledTime(e.target.value)}
                      data-testid="input-time" className={inputClass} />
                  </div>
                </div>
              )}
            </div>

            <div className={`${cardClass} p-5 space-y-3`}>
              <div>
                <label className={labelClass}>{t.common.phone} *</label>
                <div className="relative">
                  <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} required
                    data-testid="input-phone" placeholder={t.services.phonePlaceholder}
                    className={inputWithIconClass} />
                </div>
              </div>

              <div>
                <label className={labelClass}>{t.common.address}</label>
                <div className="relative">
                  <MapPin size={14} className="absolute left-3 top-3 text-gray-400" />
                  <input type="text" value={address} onChange={e => setAddress(e.target.value)}
                    data-testid="input-address" placeholder={t.services.addressPlaceholder}
                    className={inputWithIconClass} />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1 flex items-center gap-1">
                  <DollarSign size={12} />
                  {t.services.yourPrice}
                  {minPrice && <span className="text-gray-400 font-normal">({t.services.minPrice}: ${minPrice})</span>}
                </label>
                <div className="relative">
                  <DollarSign size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input type="text" value={budget} onChange={e => handleBudgetChange(e.target.value)}
                    onBlur={() => validatePrice(budget)}
                    data-testid="input-budget"
                    placeholder={catalogItemPrice ? `${t.services.minPrice}: ${catalogItemPrice}` : t.services.budgetPlaceholder}
                    className={`w-full pl-9 pr-3 py-2.5 bg-gray-50 dark:bg-gray-800 border rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:ring-2 focus:outline-none ${
                      priceError ? "border-red-400 focus:ring-red-500 bg-red-50 dark:bg-red-950/40" : "border-gray-200 dark:border-gray-700 focus:ring-red-500"
                    }`} />
                </div>
                {priceError && (
                  <div className="flex items-center gap-1.5 mt-1.5 text-red-600" data-testid="text-price-error">
                    <AlertTriangle size={12} />
                    <p className="text-[11px] font-semibold">{priceError}</p>
                  </div>
                )}
              </div>
            </div>

            <div className={`${cardClass} p-5`}>
              <label className={labelClass}>{t.services.optionalNotes}</label>
              <textarea value={additionalInfo} onChange={e => setAdditionalInfo(e.target.value)}
                data-testid="input-additional-info" placeholder={t.services.optionalNotesPlaceholder}
                className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 rounded-xl text-sm resize-none h-20 focus:ring-2 focus:ring-red-500 focus:outline-none" />
            </div>

            <div className={`${cardClass} p-5`}>
              <h3 className={sectionTitleClass}>
                <MessageCircle size={16} className="text-red-500" />
                {t.services.preferredContact}
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { key: "phone", label: t.services.telephone, icon: Phone },
                  { key: "whatsapp", label: t.services.whatsapp, icon: MessageCircle },
                  { key: "email", label: t.common.email, icon: FileText },
                ].map(opt => (
                  <button key={opt.key} type="button" onClick={() => setContactMethod(opt.key)}
                    data-testid={`button-contact-${opt.key}`}
                    className={`py-3 rounded-xl text-xs font-semibold flex flex-col items-center gap-1.5 transition-all ${contactMethod === opt.key ? "bg-red-600 text-white shadow-lg shadow-red-200" : "bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700"}`}>
                    <opt.icon size={16} />
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <button type="submit" disabled={createMutation.isPending}
              data-testid="button-submit-request"
              className="w-full bg-red-600 text-white py-4 rounded-2xl text-sm font-bold hover:bg-red-700 disabled:opacity-50 shadow-xl shadow-red-200 flex items-center justify-center gap-2">
              {createMutation.isPending ? <Loader2 size={18} className="animate-spin" /> : <Send size={16} />}
              {createMutation.isPending ? t.services.sending : t.services.sendRequest}
            </button>
          </form>
        </div>
      </div>
    );
  }

  const typeOptions = serviceTypeOptions[categoryName] || serviceTypeOptions["Autre"];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24">
      <ClientNav />
      <div className="max-w-lg mx-auto px-4 py-4">
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => navigate("/services")} className="w-10 h-10 bg-white dark:bg-gray-900 rounded-xl flex items-center justify-center border border-gray-200 dark:border-gray-700" data-testid="button-back">
            <ArrowLeft size={18} className="dark:text-gray-300" />
          </button>
          <div>
            <h2 className="text-lg font-bold text-gray-900 dark:text-white" data-testid="text-form-title">{t.services.newRequest}</h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">{categoryName}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className={`${cardClass} p-5`}>
            <h3 className={sectionTitleClass}>
              <Calendar size={16} className="text-red-500" />
              {t.services.dateTime}
            </h3>
            <div className="flex gap-2 mb-3">
              <button type="button" onClick={() => setScheduledType("asap")}
                data-testid="button-asap"
                className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all ${scheduledType === "asap" ? "bg-red-600 text-white shadow-lg shadow-red-200" : "bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700"}`}>
                <Clock size={14} className="inline mr-1.5" />{t.services.asap}
              </button>
              <button type="button" onClick={() => setScheduledType("scheduled")}
                data-testid="button-schedule"
                className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all ${scheduledType === "scheduled" ? "bg-red-600 text-white shadow-lg shadow-red-200" : "bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700"}`}>
                <Calendar size={14} className="inline mr-1.5" />{t.services.schedule}
              </button>
            </div>
            {scheduledType === "scheduled" && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>{t.common.date}</label>
                  <input type="date" value={scheduledDate} onChange={e => setScheduledDate(e.target.value)}
                    data-testid="input-date" className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Heure</label>
                  <input type="time" value={scheduledTime} onChange={e => setScheduledTime(e.target.value)}
                    data-testid="input-time" className={inputClass} />
                </div>
              </div>
            )}
          </div>

          <div className={`${cardClass} p-5 space-y-3`}>
            <h3 className={sectionTitleClass}>
              <User size={16} className="text-red-500" />
              {t.services.personalInfo}
            </h3>
            <div>
              <label className={labelClass}>{t.services.fullName} *</label>
              <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} required
                data-testid="input-fullname" placeholder={t.services.fullNamePlaceholder}
                className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>{t.common.phone} *</label>
              <div className="relative">
                <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} required
                  data-testid="input-phone" placeholder={t.services.phonePlaceholder}
                  className={inputWithIconClass} />
              </div>
            </div>
            <div>
              <label className={labelClass}>{t.common.address} *</label>
              <div className="relative">
                <MapPin size={14} className="absolute left-3 top-3 text-gray-400" />
                <input type="text" value={address} onChange={e => setAddress(e.target.value)} required
                  data-testid="input-address" placeholder={t.services.addressPlaceholder}
                  className={inputWithIconClass} />
              </div>
            </div>
          </div>

          <div className={`${cardClass} p-5 space-y-3`}>
            <h3 className={sectionTitleClass}>
              <Tag size={16} className="text-red-500" />
              {t.services.serviceDetails}
            </h3>
            <div>
              <label className={labelClass}>{t.services.serviceType} {categoryName}</label>
              <select value={serviceType} onChange={e => setServiceType(e.target.value)}
                data-testid="select-service-type"
                className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white rounded-xl text-sm focus:ring-2 focus:ring-red-500 focus:outline-none">
                <option value="">{t.services.select}</option>
                {typeOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
              </select>
            </div>
            <div>
              <label className={labelClass}>{t.services.estimatedBudget}</label>
              <div className="relative">
                <DollarSign size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input type="text" value={budget} onChange={e => setBudget(e.target.value)}
                  data-testid="input-budget" placeholder={t.services.budgetPlaceholder}
                  className={inputWithIconClass} />
              </div>
            </div>
            <div>
              <label className={labelClass}>{t.services.additionalInfo}</label>
              <textarea value={additionalInfo} onChange={e => setAdditionalInfo(e.target.value)}
                data-testid="input-additional-info" placeholder={t.services.additionalInfoPlaceholder}
                className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 rounded-xl text-sm resize-none h-24 focus:ring-2 focus:ring-red-500 focus:outline-none" />
            </div>
          </div>

          <div className={`${cardClass} p-5`}>
            <h3 className={sectionTitleClass}>
              <MessageCircle size={16} className="text-red-500" />
              {t.services.preferredContact}
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[
                { key: "phone", label: t.services.telephone, icon: Phone },
                { key: "whatsapp", label: t.services.whatsapp, icon: MessageCircle },
                { key: "email", label: t.common.email, icon: FileText },
              ].map(opt => (
                <button key={opt.key} type="button" onClick={() => setContactMethod(opt.key)}
                  data-testid={`button-contact-${opt.key}`}
                  className={`py-3 rounded-xl text-xs font-semibold flex flex-col items-center gap-1.5 transition-all ${contactMethod === opt.key ? "bg-red-600 text-white shadow-lg shadow-red-200" : "bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-700"}`}>
                  <opt.icon size={16} />
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <button type="submit" disabled={createMutation.isPending}
            data-testid="button-submit-request"
            className="w-full bg-red-600 text-white py-4 rounded-2xl text-sm font-bold hover:bg-red-700 disabled:opacity-50 shadow-xl shadow-red-200 flex items-center justify-center gap-2">
            {createMutation.isPending ? <Loader2 size={18} className="animate-spin" /> : <Send size={16} />}
            {createMutation.isPending ? t.services.sending : t.services.sendRequest}
          </button>
        </form>
      </div>
    </div>
  );
}
