# MAWEJA — GitHub Actions Build Guide
**Base URL : https://maweja.net**

## Contenu de ce ZIP

```
.github/
  workflows/
    build-android.yml   → Build APK/AAB Client + Driver
    build-ios.yml       → Build IPA Client (macOS)
mobile/
  client/
    capacitor.config.ts → Config Capacitor Client (com.edcorp.maweja)
    package.json        → Dépendances Capacitor Client
  driver/
    capacitor.config.ts → Config Capacitor Driver (com.edcorp.maweja.driver)
    package.json        → Dépendances Capacitor Driver
```

## Permissions incluses automatiquement

### Android (injectées dans AndroidManifest.xml)
- ACCESS_FINE_LOCATION + ACCESS_COARSE_LOCATION (géolocalisation)
- ACCESS_BACKGROUND_LOCATION (suivi en arrière-plan)
- FOREGROUND_SERVICE + FOREGROUND_SERVICE_LOCATION
- POST_NOTIFICATIONS (Android 13+)
- VIBRATE + WAKE_LOCK + RECEIVE_BOOT_COMPLETED (notifications)
- CAMERA + READ_MEDIA_IMAGES (photo profil)
- ACCESS_NETWORK_STATE + ACCESS_WIFI_STATE

### iOS (injectées dans Info.plist)
- NSLocationWhenInUseUsageDescription
- NSLocationAlwaysAndWhenInUseUsageDescription
- NSCameraUsageDescription
- NSPhotoLibraryUsageDescription
- NSMicrophoneUsageDescription

## Icônes
Les icônes MAWEJA sont générées automatiquement depuis `client/public/logo.png`
(déjà présent dans votre repo).

## Secrets GitHub requis (Settings → Secrets → Actions)

### Obligatoires pour le build Android Release
| Secret | Description |
|--------|-------------|
| `CLIENT_KEYSTORE_BASE64` | Keystore Client en base64 |
| `CLIENT_KEYSTORE_PASSWORD` | Mot de passe du keystore |
| `CLIENT_KEY_ALIAS` | Alias de la clé |
| `CLIENT_KEY_PASSWORD` | Mot de passe de la clé |
| `DRIVER_KEYSTORE_BASE64` | Keystore Driver en base64 |
| `DRIVER_KEYSTORE_PASSWORD` | Mot de passe du keystore |
| `DRIVER_KEY_ALIAS` | Alias de la clé |
| `DRIVER_KEY_PASSWORD` | Mot de passe de la clé |

### Optionnels (déjà codé en dur = https://maweja.net)
| Secret | Description |
|--------|-------------|
| `API_BASE_URL` | Si absent → `https://maweja.net` par défaut |

### Pour iOS Release (uniquement)
| Secret | Description |
|--------|-------------|
| `IOS_CERTIFICATE_BASE64` | Certificat Apple (.p12 en base64) |
| `IOS_CERTIFICATE_PASSWORD` | Mot de passe du .p12 |
| `IOS_PROVISION_PROFILE_BASE64` | Profil de provisioning en base64 |
| `IOS_PROVISION_PROFILE_NAME` | Nom du profil |
| `IOS_TEAM_ID` | Team ID Apple Developer |

## Comment utiliser

### 1. Copier ces fichiers dans votre repo GitHub
Extrayez ce ZIP et copiez les dossiers `.github/` et `mobile/` à la racine de votre repo.

### 2. Lancer un build Android Debug (APK)
GitHub → Actions → "Build Android" → Run workflow → Type: debug

### 3. Lancer un build Android Release (AAB pour Play Store)
1. Créer votre keystore :
   ```bash
   keytool -genkey -v -keystore maweja-client.jks -alias maweja -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Encoder en base64 :
   ```bash
   base64 -i maweja-client.jks | pbcopy  # macOS
   base64 -w 0 maweja-client.jks          # Linux
   ```
3. Ajouter les secrets dans GitHub
4. GitHub → Actions → "Build Android" → Run workflow → Type: release

### 4. Télécharger les APK/AAB générés
GitHub → Actions → Votre workflow → Artifacts → Télécharger

---
Made By Khevin Andrew Kita - Ed Corporation | Contact: 0819994041
