import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import ClientNav from "../../components/ClientNav";
import AdBanner from "../../components/AdBanner";
import { useAuth } from "../../lib/auth";
import { useI18n } from "../../lib/i18n";
import { Star, Clock, MapPin, Search, ChevronRight, Flame, ChefHat, X, Zap, TrendingUp, Scissors, Hand, Heart, Home as HomeIcon, ArrowRight } from "lucide-react";
import { formatPrice } from "../../lib/utils";
import type { Restaurant, PromoBanner } from "@shared/schema";

function PromoBannerBlock() {
  const { data: banner } = useQuery<PromoBanner>({ queryKey: ["/api/promo-banner"] });

  const defaults = {
    tagText: "Offre Spéciale",
    title: "Livraison gratuite",
    subtitle: "Sur votre première commande",
    buttonText: "Commander maintenant",
    bgColorFrom: "#dc2626",
    bgColorTo: "#b91c1c",
    isActive: true,
    linkUrl: null as string | null,
  };
  const b = { ...defaults, ...banner };
  if (!b.isActive) return null;

  const content = (
    <div
      className="rounded-3xl p-5 mb-5 text-white relative overflow-hidden"
      style={{ background: `linear-gradient(135deg, ${b.bgColorFrom} 0%, ${b.bgColorTo} 100%)` }}
      data-testid="promo-banner"
    >
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-8 -right-8 w-36 h-36 rounded-full bg-white/10" />
        <div className="absolute -bottom-6 right-12 w-24 h-24 rounded-full bg-white/5" />
        <div className="absolute top-3 right-1/3 w-3 h-3 rounded-full bg-white/20 animate-ping" style={{ animationDuration: "3s" }} />
      </div>
      <div className="relative z-10">
        <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full mb-3">
          <Flame size={12} />
          <span className="text-xs font-bold uppercase tracking-wider">{b.tagText}</span>
        </div>
        <h3 className="text-xl font-black leading-tight">{b.title}</h3>
        <p className="text-white/80 text-sm mt-1">{b.subtitle}</p>
        {b.buttonText && (
          <button
            className="mt-4 bg-white px-5 py-2 rounded-xl text-xs font-black shadow-lg active:scale-95 transition-all"
            style={{ color: b.bgColorFrom }}
            data-testid="button-promo"
          >
            {b.buttonText} →
          </button>
        )}
      </div>
    </div>
  );

  if (b.linkUrl) return <a href={b.linkUrl} target="_blank" rel="noopener noreferrer">{content}</a>;
  return content;
}

const categories = [
  { name: "🍽️ Tous", nameEn: "🍽️ All", cuisine: null },
  { name: "🇨🇩 Congolais", nameEn: "🇨🇩 Congolese", cuisine: "Congolais" },
  { name: "🍔 Burgers", nameEn: "🍔 Burgers", cuisine: "Burgers" },
  { name: "🍕 Pizza", nameEn: "🍕 Pizza", cuisine: "Pizza" },
  { name: "☕ Café & Brunch", nameEn: "☕ Café & Brunch", cuisine: "Café & Brunch" },
  { name: "🔥 Grillades", nameEn: "🔥 Grills", cuisine: "Grillades" },
  { name: "🌯 Fast Food", nameEn: "🌯 Fast Food", cuisine: "Fast Food" },
  { name: "⭐ Gastro", nameEn: "⭐ Fine Dining", cuisine: "Gastronomique" },
  { name: "🧆 Libanais", nameEn: "🧆 Lebanese", cuisine: "Libanais" },
  { name: "🌍 International", nameEn: "🌍 International", cuisine: "International" },
];

function RestaurantCard({ r, idx, onClick }: { r: Restaurant; idx: number; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      data-testid={`restaurant-card-${r.id}`}
      className={`w-full bg-white dark:bg-gray-900 rounded-3xl overflow-hidden active:scale-[0.97] transition-all duration-200 text-left fade-in-up stagger-${Math.min(idx + 1, 6)}`}
      style={{ boxShadow: "0 2px 20px rgba(0,0,0,0.08), 0 0 0 1px rgba(0,0,0,0.04)" }}
    >
      {/* Cover image */}
      <div className="relative h-44">
        <img src={r.image} alt={r.name} className="w-full h-full object-cover" loading="lazy" />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

        {/* Closed overlay */}
        {!r.isActive && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-sm">
            <span className="text-white font-black text-sm bg-black/70 px-4 py-2 rounded-xl tracking-wide">FERMÉ</span>
          </div>
        )}

        {/* Rating badge */}
        <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-sm rounded-2xl px-2.5 py-1.5 flex items-center gap-1 shadow-lg">
          <Star size={11} className="text-amber-500 fill-amber-500" />
          <span className="text-xs font-black text-gray-900">{r.rating}</span>
        </div>

        {/* Top-left badge for popular */}
        {r.rating >= 4.7 && (
          <div className="absolute top-3 left-3 bg-amber-500 text-white rounded-xl px-2.5 py-1 flex items-center gap-1">
            <TrendingUp size={10} />
            <span className="text-[10px] font-black uppercase tracking-wide">Top</span>
          </div>
        )}

        {/* Bottom info overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4 flex items-end justify-between">
          <div className="flex items-center gap-2.5">
            {/* Restaurant logo */}
            <div className="w-12 h-12 rounded-2xl bg-white shadow-xl flex items-center justify-center overflow-hidden flex-shrink-0 ring-2 ring-white/50">
              {r.logoUrl ? (
                <img src={r.logoUrl} alt={`${r.name} logo`} className="w-full h-full object-contain p-1"
                  data-testid={`restaurant-logo-${r.id}`} loading="lazy" />
              ) : (
                <span className="text-red-600 font-black text-lg">{r.name.charAt(0)}</span>
              )}
            </div>
            <div>
              <h4 className="font-black text-white text-base leading-tight drop-shadow">{r.name}</h4>
              <span className="text-white/80 text-xs font-medium">{r.cuisine}</span>
            </div>
          </div>
          {/* Delivery time pill */}
          <div className="flex items-center gap-1 bg-black/40 backdrop-blur-sm px-2.5 py-1.5 rounded-xl">
            <Zap size={10} className="text-amber-400" />
            <span className="text-white text-[11px] font-bold">{r.deliveryTime}</span>
          </div>
        </div>
      </div>

      {/* Card body */}
      <div className="px-4 py-3">
        <p className="text-gray-500 dark:text-gray-400 text-xs line-clamp-1 mb-3">{r.description}</p>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 text-gray-400 dark:text-gray-500">
            <ChefHat size={10} />
            <span className="text-[11px] font-medium">{r.prepTime || r.deliveryTime}</span>
          </div>
          <div className="w-px h-3 bg-gray-200 dark:bg-gray-700" />
          <div className="flex items-center gap-1 text-gray-400 dark:text-gray-500 min-w-0">
            <MapPin size={10} className="flex-shrink-0" />
            <span className="text-[11px] font-medium truncate">{r.address.split(",")[0]}</span>
          </div>
          <div className="ml-auto text-[11px] font-black text-red-600 bg-red-50 dark:bg-red-900/20 px-2.5 py-1 rounded-xl">
            {formatPrice(r.deliveryFee)} livraison
          </div>
        </div>
      </div>
    </button>
  );
}

export default function HomePage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { t, lang } = useI18n();
  const { data: restaurants = [], isLoading } = useQuery<Restaurant[]>({ queryKey: ["/api/restaurants"] });
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showAll, setShowAll] = useState(false);

  const availableCuisines = new Set(restaurants.map(r => r.cuisine));
  const visibleCategories = categories.filter(c => c.cuisine === null || availableCuisines.has(c.cuisine));

  const filtered = restaurants.filter(r => {
    if (activeCategory && r.cuisine !== activeCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return r.name.toLowerCase().includes(q) || r.cuisine.toLowerCase().includes(q) || r.description.toLowerCase().includes(q);
    }
    return true;
  });

  const displayedRestaurants = showAll || activeCategory || searchQuery.trim() ? filtered : filtered.slice(0, 6);
  const featuredRestaurants = restaurants.filter(r => r.rating >= 4.6).slice(0, 4);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-24">
      <ClientNav />

      <div className="max-w-lg mx-auto px-4 pt-4">

        {/* Greeting */}
        <div className="mb-5 fade-in-up">
          <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">
            {user ? `${t.client.hello} ${user.name?.split(" ")[0]} 👋` : "Bienvenue sur MAWEJA 👋"}
          </p>
          <h2 className="text-2xl font-black text-gray-900 dark:text-white mt-0.5 leading-tight">
            {t.client.whatToEat}
          </h2>
        </div>

        {/* Search bar */}
        <div className="relative mb-5 fade-in-up stagger-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder={t.client.searchPlaceholder}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search"
            className="w-full pl-11 pr-10 py-3.5 bg-white dark:bg-gray-900 rounded-2xl text-sm text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
            style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.04)" }}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500 transition-colors" data-testid="button-clear-search">
              <X size={16} />
            </button>
          )}
        </div>

        {/* Ads */}
        <div className="fade-in-up stagger-2"><AdBanner /></div>

        {/* Promo banner */}
        <div className="fade-in-up stagger-3"><PromoBannerBlock /></div>

        {/* Services MAWEJA card */}
        {!searchQuery && !activeCategory && (
          <div className="mb-6 fade-in-up stagger-4">
            <button
              onClick={() => navigate("/services")}
              data-testid="services-card"
              className="w-full rounded-3xl overflow-hidden active:scale-[0.98] transition-all duration-200 text-left relative"
              style={{ background: "linear-gradient(135deg, #1e1b4b 0%, #312e81 40%, #4c1d95 100%)", boxShadow: "0 8px 32px rgba(49,46,129,0.35)" }}
            >
              {/* Background decorations */}
              <div className="absolute inset-0 overflow-hidden">
                <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full bg-white/5" />
                <div className="absolute -bottom-8 left-8 w-32 h-32 rounded-full bg-white/5" />
                <div className="absolute top-4 right-1/3 w-2 h-2 rounded-full bg-violet-300/40 animate-ping" style={{ animationDuration: "3s" }} />
              </div>
              <div className="relative z-10 p-5">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="inline-flex items-center gap-1.5 bg-white/15 backdrop-blur-sm px-3 py-1 rounded-full mb-2">
                      <span className="text-[10px] font-black text-violet-200 uppercase tracking-wider">À domicile · Kinshasa</span>
                    </div>
                    <h3 className="text-xl font-black text-white leading-tight">Services MAWEJA</h3>
                    <p className="text-violet-200/80 text-xs mt-1">Coiffure, Massage, Ménage &amp; plus</p>
                  </div>
                  <div className="w-10 h-10 bg-white/15 rounded-2xl flex items-center justify-center flex-shrink-0">
                    <ArrowRight size={18} className="text-white" />
                  </div>
                </div>
                {/* Service icons grid */}
                <div className="flex gap-3">
                  {[
                    { icon: Scissors, label: "Coiffure", bg: "bg-pink-500/20" },
                    { icon: Hand, label: "Manucure", bg: "bg-rose-500/20" },
                    { icon: Heart, label: "Massage", bg: "bg-red-500/20" },
                    { icon: HomeIcon, label: "Ménage", bg: "bg-violet-500/20" },
                  ].map(({ icon: Icon, label, bg }) => (
                    <div key={label} className="flex-1 flex flex-col items-center gap-1.5">
                      <div className={`w-11 h-11 rounded-2xl ${bg} backdrop-blur-sm flex items-center justify-center border border-white/10`}>
                        <Icon size={18} className="text-white" />
                      </div>
                      <span className="text-[9px] font-bold text-violet-200/90 text-center leading-tight">{label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </button>
          </div>
        )}

        {/* Featured strip (horizontal scroll) - only when no search/filter */}
        {!searchQuery && !activeCategory && featuredRestaurants.length > 0 && (
          <div className="mb-6 fade-in-up stagger-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-5 bg-red-600 rounded-full" />
                <h3 className="text-base font-black text-gray-900 dark:text-white">⭐ Les meilleurs</h3>
              </div>
            </div>
            <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-1 px-1 pb-1">
              {featuredRestaurants.map(r => (
                <button
                  key={r.id}
                  onClick={() => navigate(`/restaurant/${r.id}`)}
                  data-testid={`featured-card-${r.id}`}
                  className="flex-shrink-0 w-44 bg-white dark:bg-gray-900 rounded-2xl overflow-hidden active:scale-[0.96] transition-all"
                  style={{ boxShadow: "0 4px 16px rgba(0,0,0,0.10)" }}
                >
                  <div className="relative h-28">
                    <img src={r.image} alt={r.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-2 left-2 right-2">
                      <div className="flex items-center gap-1 bg-white/20 backdrop-blur-sm rounded-lg px-1.5 py-0.5 w-fit">
                        <Star size={9} className="text-amber-400 fill-amber-400" />
                        <span className="text-white text-[10px] font-black">{r.rating}</span>
                      </div>
                    </div>
                  </div>
                  <div className="p-2.5">
                    <p className="font-black text-gray-900 dark:text-white text-xs leading-tight line-clamp-1">{r.name}</p>
                    <p className="text-gray-400 text-[10px] mt-0.5 flex items-center gap-1">
                      <Clock size={9} />{r.deliveryTime}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Category pills */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar mb-5 -mx-1 px-1 fade-in-up stagger-5 pb-0.5">
          {visibleCategories.map((c) => {
            const isActive = activeCategory === c.cuisine;
            return (
              <button
                key={c.name}
                onClick={() => { setActiveCategory(isActive ? null : c.cuisine); setShowAll(false); }}
                data-testid={`category-${c.name.toLowerCase().replace(/[\s🍽️🇨🇩🍔🍕☕🔥🌯⭐🧆🌍]/g, "").toLowerCase().replace(/[&]/g, "").replace(/\s+/g, "-")}`}
                className={`flex-shrink-0 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all duration-200 active:scale-95 whitespace-nowrap ${
                  isActive
                    ? "bg-red-600 text-white shadow-lg"
                    : "bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-400 hover:bg-red-50 dark:hover:bg-gray-800"
                }`}
                style={isActive ? { boxShadow: "0 4px 16px rgba(220,38,38,0.4)" } : { boxShadow: "0 1px 6px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.04)" }}
              >
                {lang === "en" ? c.nameEn : c.name}
              </button>
            );
          })}
        </div>

        {/* Section header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-5 bg-red-600 rounded-full" />
            <h3 className="text-base font-black text-gray-900 dark:text-white">
              {activeCategory ? (categories.find(c => c.cuisine === activeCategory)?.name ?? activeCategory)
                : searchQuery ? t.client.results
                : t.client.popularRestaurants}
            </h3>
          </div>
          {!showAll && !activeCategory && !searchQuery && filtered.length > 6 && (
            <button onClick={() => setShowAll(true)} className="flex items-center gap-0.5 text-red-600 text-xs font-bold" data-testid="button-see-all">
              {t.common.seeAll} <ChevronRight size={14} />
            </button>
          )}
          {(showAll || activeCategory || searchQuery) && (
            <span className="text-xs text-gray-400 font-medium" data-testid="text-result-count">
              {filtered.length} {t.common.restaurant}{filtered.length !== 1 ? "s" : ""}
            </span>
          )}
        </div>

        {/* Restaurant list */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white dark:bg-gray-900 rounded-3xl overflow-hidden" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
                <div className="h-44 skeleton-shimmer" />
                <div className="p-4 space-y-3">
                  <div className="h-2.5 w-full skeleton-shimmer rounded-full" />
                  <div className="flex gap-3">
                    <div className="h-2 w-20 skeleton-shimmer rounded-full" />
                    <div className="h-2 w-28 skeleton-shimmer rounded-full" />
                    <div className="ml-auto h-2 w-16 skeleton-shimmer rounded-full" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : displayedRestaurants.length === 0 ? (
          <div className="bg-white dark:bg-gray-900 rounded-3xl p-12 text-center fade-in" data-testid="text-no-results"
            style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search size={28} className="text-gray-300 dark:text-gray-600" />
            </div>
            <p className="text-gray-700 dark:text-gray-300 font-bold">{t.client.noRestaurant}</p>
            <p className="text-gray-400 dark:text-gray-500 text-sm mt-1">
              {searchQuery ? t.client.tryOtherSearch : t.client.noInCategory}
            </p>
            <button
              onClick={() => { setActiveCategory(null); setSearchQuery(""); setShowAll(false); }}
              className="mt-4 bg-red-600 text-white text-sm font-bold px-6 py-2.5 rounded-xl active:scale-95 transition-all"
              data-testid="button-reset-filters"
            >
              {t.client.seeAllRestaurants}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {displayedRestaurants.map((r, idx) => (
              <RestaurantCard key={r.id} r={r} idx={idx} onClick={() => navigate(`/restaurant/${r.id}`)} />
            ))}
          </div>
        )}

        {/* Show more */}
        {!showAll && !activeCategory && !searchQuery && filtered.length > 6 && (
          <button
            onClick={() => setShowAll(true)}
            data-testid="button-load-more"
            className="w-full mt-4 py-3.5 rounded-2xl border-2 border-dashed border-gray-200 dark:border-gray-700 text-gray-500 dark:text-gray-400 text-sm font-bold hover:border-red-300 hover:text-red-600 transition-all active:scale-[0.98]"
          >
            Voir tous les restaurants ({filtered.length})
          </button>
        )}
      </div>
    </div>
  );
}
